import pandas as pd
import mod

df = pd.read_csv("data/train_df.csv")

